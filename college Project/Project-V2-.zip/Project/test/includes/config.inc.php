<?php
  session_start();
  $servername = "localhost"; 
  $dBUsername = "root";
  $dBPassword = "qwerty67";
  $dBName = "hostel_management_system";

  $conn=mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);

  if (!$conn) {
    die("Connection Failed: ".mysqli_connect_error());
  }
?>
