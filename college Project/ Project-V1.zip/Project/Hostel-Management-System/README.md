# Hostel-Management-System
A system built for hostel room allocation for our College(NIT Calicut) as a part of DBMS Course.

### For more details regarding the system please refer to SDD, SRS, UserManual of the system in Documentation folder.
